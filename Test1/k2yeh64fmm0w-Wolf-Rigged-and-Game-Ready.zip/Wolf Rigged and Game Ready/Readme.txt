Here is my low-poly wolf model with some basic animations.

http://wp.me/P3dmoi-1uc

Wolf animations:

-Walk cycle
-Run cycle
-Sit
-Creep cycles
-Idle animation


I modeled, textured and rigged this wolf in Blender from 14.03.2011 to 05.04.2011.4
https://3dhaupt.com/3d-wolf-rigged-low-poly-and-game-ready-download-walk-cycle-run-sit-creep-idle-animation/wolf-work-in-progress-09-11-2009-31-01-2010/

Wolf animation control in Blender Game Engine:
    
-W-Key = Walk cycle
-E-Key = Run cycle
-R-Key = Creep cycle
-Spacebar = Sit

Wolf test in Unreal 4
https://www.youtube.com/watch?v=GqZs8_5roaM&

Wolf test in Unity 5
https://www.youtube.com/watch?v=ztQ6sMVhUZ0&

3d and animation preview on Sketchfab
https://sketchfab.com/models/f3769a474a714ebbbaca0d97f9b0a5a0

Downloads:

Google-Drive 
https://goo.gl/M6PKSK

Blendswap 
http://www.blendswap.com/blends/view/24800

Sketchfab 
https://sketchfab.com/models/f3769a474a714ebbbaca0d97f9b0a5a0#download

CGTrader 
https://www.cgtrader.com/3d-models/animals/mammal/wolf-rigged-low-poly-and-game-ready-251ea7f873a2b89da7b01637ebd00617

TF3dmhttps://www.cgtrader.com/3d-models/animals/mammal/wolf-rigged-low-poly-and-game-ready-251ea7f873a2b89da7b01637ebd00617

ShareCG
https://www.sharecg.com/v/80818/view/5/3D-Model/Wolf-model-for-the-blender-game-engine

Available formats:

Blender (.blend) (5 files)
Autodesk FBX (.fbx) (6 files)
Unity 3D (.unitypackage) 
3D Studio (.3ds)
Collada (.dae) 
Alias/WaveFront Material (.mtl) 
OBJ (.obj) 175 KB
UnrealEngine Unreal Engine 4 (.uasset) 
Maya (.ma/.mb) 